TRUSTTRAIL — DEPLOYMENT PACKAGE

Brand: TrustTrail
Tagline: Explore with confidence. Travel with clarity.
Creator attribution: Original concept and product design by Lavender Akinyi
Copyright notice: © 2026 Lavender Akinyi. All rights reserved.

FILES
- TrustTrail_Refined.html: standalone website prototype
- trusttrail-favicon.svg: browser tab icon
- trusttrail-social-card.svg: social sharing preview artwork

DEPLOYMENT NOTE
Keep all three files in the same folder when publishing. The HTML references the favicon and social card by relative path. After the site has a public HTTPS URL, update the og:image and twitter:image meta tags in the HTML to the full absolute HTTPS URL of trusttrail-social-card.svg; social crawlers generally expect an absolute image URL. If you use a custom domain, ensure it points to this deployment.

ATTRIBUTION NOTE
The attribution and copyright metadata express the project's stated authorship and claim; they do not independently register a trademark or determine ownership of third-party materials. External photographs, research sources and other third-party assets remain subject to their respective licences and terms.

This package does not itself publish the website to the internet. Upload these files to a hosting provider you control.
